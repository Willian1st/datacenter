'use strict';
var aB = require('../a/b.js');
var cD = require('./d.js');
var opt;
opt(aB + cD);
