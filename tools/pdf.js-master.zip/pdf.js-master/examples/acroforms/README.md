## Overview

Example to demonstrate PDF.js library usage for rendering files with AcroForms.

## Getting started

Build PDF.js using `gulp dist` and run `gulp server` to start a web server.
You can then work with the example at
http://localhost:8888/examples/acroforms/acroforms.html.

Refer to `acroforms.js` for the source code of the example.
