'use strict';

var styleDirective = valueFn({
  restrict: 'E',
  terminal: false
});
