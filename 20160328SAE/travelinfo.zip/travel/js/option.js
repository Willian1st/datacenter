$(function() {
	$("#bus_info").on('click', function() {
		window.location.href = "travel";
	});
	$("#ip_info").on('click', function() {
		window.location.href = "ip";
	});
	$("#weather_info").on('click', function() {
		window.location.href = "weather";
	});
	$("#color-info").on('click', function() {
		window.location.href = "color";
	});
	$("#option").on('click', function() {
		window.location.href = "option";
	});
	$("#position").on('click', function() {
		window.location.href = "position";
	});
	$("#url").on('click', function() {
		window.location.href = "../php/converter";
	});
	$("#rmb").on('click', function() {
		window.location.href = "rmb";
	});
});
