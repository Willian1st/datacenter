/**
 * 通用js
 */
var alertHtml='<div id="resultAlert" class="alert alert-success" style="position: relative; margin-top: -70%; z-index: 9999; display: none"> <a class="close">&times;</a> 提示 <p> <center>保存成功...</center> </div>''