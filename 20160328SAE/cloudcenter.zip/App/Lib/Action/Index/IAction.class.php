<?php


//接口
class IAction extends Action {
	/**
	 * 设备新增
	 */
	public function deviceAdd() {
		$model = M('device');
		$data['time'] = time();
		$deviceid = '-1';
		$userid = '-1';
		$sim = '-1';
		$where = '';
		if (isset ($_POST['deviceid']) && !empty ($_POST['deviceid'])) {
			$data['deviceid'] = $_POST['deviceid'];
		}
		if (isset ($_POST['userid']) && !empty ($_POST['userid'])) {
			$data['userid'] = $_POST['userid'];
		}
		if (isset ($_POST['sim']) && !empty ($_POST['sim'])) {
			$sim = $_POST['sim'];
			$data['sim'] = $sim;
			$where = " sim='$sim' ";
		}
		$total = $model->where($where)->count();
		if ($total <= 0) {
			$model->add($data);
		}
	}
	/**
	 * 检察权限
	 */
	public function deviceCheck() {
		$model = M('device');
		$sim = $_POST['sim'];
		$where = " sim='$sim' ";
		$dataList = $model->where($where)->select();
		$groupList = array ();
		if (!empty ($dataList)) {
			foreach ($dataList as $data) {
				array_push($groupList, $data);
				$id = $data['id'];
				$result = M('device');
				$result->where('id=' . $id)->setField($data = array (
					'checktime' => time()
				));
			}
		}
		$total = $model->where($where)->count();
		$groupList = ($groupList == null) ? "[]" : json_encode($groupList);
		$json = '{"total":' . $total . ',"rows":' . $groupList . '}';
		echo $json;
	}
	
	/**
	 * 检查新版本
	 */
	public function deviceUpdate() {
		echo '{"version":20160223}';
	}
	/**
	 * 应用信息新增
	 */
	public function redbagAdd() {
		$agent = $_SERVER['HTTP_USER_AGENT'];
		$ip = get_client_ip();
		$host = $_SERVER['SERVER_NAME'] . ':' . $_SERVER["SERVER_PORT"] . $_SERVER["REQUEST_URI"];
		$model = M('loghistory');
		$data['visittime'] = time();
		$data['agent'] = $agent;
		$data['ip'] = $ip;
		$data['host'] = $host;
		$data['request'] = $_POST['request'];
		$data['infos'] = $_POST['infos'];
		$data['detail'] = $_POST['detail'];
		$total = 0;
		if (isset ($_POST['infos']) && !empty ($_POST['infos'])) {
			//判断是否已存在
			$infos = trim($data['infos']);
			$where = " trim(infos)='$infos' ";
			$result = M('loghistory');
			$total = $result->where($where)->count();
		}
		if ($total <= 0) {
			$address = '';
			$addr = getaddress($ip);
			foreach ($addr[0] as $value) {
				$address = $address . $value . " ";
			}
			$data['address'] = ($address == "" ? "未知" : $address);
			$model->add($data);
		}
	}
}