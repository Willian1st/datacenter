<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE>
<html lang="zh">
<head>
<meta name="viewport" content="width=device-width">
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
<title>提示</title>
<link rel="icon" href="__PUBLIC__/spyonyou.png">
</head>
<body>
	<div style='text-align: center'>本界面只能在微信中打开(⊙o⊙)哦</div>
</body>
</html>