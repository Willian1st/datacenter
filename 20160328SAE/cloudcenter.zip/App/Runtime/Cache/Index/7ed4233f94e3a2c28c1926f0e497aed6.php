<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width">
<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>
<script src="__PUBLIC__/jquery.js"></script>
<title>Welcome</title>
<script type="text/javascript" src="__PUBLIC__/js/mobile_base.js"></script>
</head>
</html>