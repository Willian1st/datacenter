<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>网页授权</title>
</head>
<body>网页授权
</body>
</html>