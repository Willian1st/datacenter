<?php


//注意，请不要在这里配置SAE的数据库，配置你本地的数据库就可以了。
return array (
	//指定错误页面
	'TMPL_EXCEPTION_FILE' => './Public/Tpl/error.html',

	
);
?>