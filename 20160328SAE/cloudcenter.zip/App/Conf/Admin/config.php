<?php


//注意，请不要在这里配置SAE的数据库，配置你本地的数据库就可以了。
return array (
	//指定错误页面
	'DB_PREFIX' => 'sae_', // 数据库表前缀 
	
);
?>