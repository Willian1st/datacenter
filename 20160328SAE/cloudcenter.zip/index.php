<?php
define('THINK_PATH','./ThinkPHP/');
define('APP_NAME','App');
define('APP_PATH','./App/');
define('APP_DEBUG',true);
//define('SAE_RUNTIME',true);
define('ENGINE_NAME','sae');
require THINK_PATH.'ThinkPHP.php';
